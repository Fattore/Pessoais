//Murilo Gomes de Fattore e Brito
//F03HBG-3
package Exercicio6;

public class Veterinario {
    public void examinar(Animal animal){
        animal.emitirSom();
    }
}
