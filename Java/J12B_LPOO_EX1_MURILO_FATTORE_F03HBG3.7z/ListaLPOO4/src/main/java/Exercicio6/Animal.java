//Murilo Gomes de Fattore e Brito
//F03HBG-3
package Exercicio6;

public abstract class Animal {
    String nome;
    int idade;
    String som;
    String meioLocomocao;
    
    public abstract void emitirSom();
    public abstract void locomocao();
}
